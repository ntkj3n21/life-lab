export type EntityType =
  "video";