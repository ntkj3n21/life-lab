param(
    [Parameter(Mandatory=$true, Position=0)]
    [string]$LogText
)

# 1. Ép kiểu UTF-8 để Console in ra tiếng Việt chuẩn xác (không bị lỗi "âš ï¸")
[console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 2. Cập nhật Regex: Bổ sung thêm ps1, md, sql (hoặc bạn có thể thêm các đuôi khác nếu cần)
# Nhờ Regex này, nó sẽ tự lờ đi phần rác "+104-0" và bóc đúng phần tên file có đuôi hợp lệ.
$files = [regex]::Matches($LogText, '[a-zA-Z0-9_/-]+\.(tsx|ts|js|jsx|css|ps1|md|sql)') | ForEach-Object { $_.Value } | Sort-Object -Unique

if ($files.Count -eq 0) {
    Write-Host "⚠️ Không tìm thấy đường dẫn file nào hợp lệ!" -ForegroundColor Yellow
    exit
}

# Nối chuỗi và tạo lệnh
$fileList = $files -join ','
$command = "npx repomix --include `"$fileList`" --output repomix-changed.xml"

Write-Host "🚀 Đã tìm thấy $($files.Count) file. Đang thực thi lệnh:" -ForegroundColor Cyan
Write-Host $command -ForegroundColor Green
Write-Host "--------------------------------------------------" -ForegroundColor DarkGray

# Thực thi lệnh tự động
Invoke-Expression $command